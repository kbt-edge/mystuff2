/***********************************************************************************************************************
 * edgeLogin.js
 *
 * Copyright © 2018 Edge Technologies
 *
 * Author: jfirebau
 **********************************************************************************************************************/
//document.title = "My Title";//uncomment and change My Title to your customized title string
var edgeLogin = angular.module('edgeLogin', []);

edgeLogin.controller('loginCtrlr', ['$scope', '$http', '$window', function ($scope, $http, $window) {

    var _this = this;
    this.showCapsLockWarning = false;
	
	this.LOGIN = "Login";
	this.LOGGING_IN = "Logging in...";

    this.capsLock = function (e) {
        var kc = e.keyCode ? e.keyCode : e.which;
        var sk = e.shiftKey ? e.shiftKey : ((kc == 16) ? true : false);
        if (((kc >= 65 && kc <= 90) && !sk) || ((kc >= 97 && kc <= 122) && sk)) {
            _this.showCapsLockWarning = true;
        } else {
            _this.showCapsLockWarning = false;
        }
        $scope.$applyAsync();
    };

    this.handleLogin = function ($event) {
        if (_this.username != undefined && _this.password != undefined) {
            var hash = decodeURI(self.document.location.hash.substring(1));
            var config = {'headers': {'Content-Type': 'application/x-www-form-urlencoded'}};
            var action = "j_spring_security_check";
			var btn = angular.element(document.querySelector('#login-btn'))
			btn.val(_this.LOGGING_IN);
			btn.addClass('disabled');
			$scope.$applyAsync();
            $http.post(action, "j_username=" + encodeURIComponent(_this.username) + "&j_password=" + encodeURIComponent(_this.password), config)
                .success(function (response) {
                    if (response.hasOwnProperty('status')) {
                        _this.loginState = response;
                        if (response.status === 'authenticated') {
                            $window.location = "/#" + hash;
                        }
                    }
                })
                .error(function (response) {
                    if (response.hasOwnProperty('status')) {
                        _this.loginState = response;
                    }
                })
				.finally(function() {
					btn.removeClass('disabled');
					btn.val(_this.LOGIN);
                    $scope.$applyAsync();
				});
        }
    };
}]);

edgeLogin.directive('edgeLogin', function () {
    return {
        restrict   : "E",
        templateUrl: "login/html/login.tpl.html",
        controller : "loginCtrlr as ctrlr"
    };
});
