
Customizing the edgeSuite login page
------------------------------------

This directory can be used to override the system provided login page
and/or login page resources. Due to security restrictions on
unauthenticated clients all referenced resources must also belong in
this location or sub-directories of this location.

  * The system provided login page and resources can be used as a starting 
    point by copying from:

    [INSTALL_HOME]/tomcat/webapps/ROOT/WEB-INF/classes/static/login/
    (NOTE: do not modify the system provided files in the location above)

  * Files in this custom location are automatically included and restored in
    backup archives.

  * Upgrading to a new release of edgeSuite may require updates to
    custom login pages.

See also [INSTALL_HOME]/jsp/.


Further information
-------------------

  * Online Documentation: http://docs.edge-technologies.com
