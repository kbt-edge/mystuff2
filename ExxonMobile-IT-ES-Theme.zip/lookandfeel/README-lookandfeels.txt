
Custom edgeSuite Look and Feels
-----------------------

This directory can be used to store custom look and feel related files (CSS and 
images).

  * To register a new look and feel by create a new directory here. The directory
    name will be the name of the look and feel. Next place all the related images,
    override.css, and setting.properties in it.

  * Using an override.css may break the product. It is recommended to
    only add overrides as necessary.

  * Files in this custom location are automatically included and restored in
    backup archives.

  * On upgrade to a new version of edgeSuite it maybe necessary to re-apply
    customizations in the override.css.


Further information
-------------------

  * Online Documentation: http://docs.edge-technologies.com
