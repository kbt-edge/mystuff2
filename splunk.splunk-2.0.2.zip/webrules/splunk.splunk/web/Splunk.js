/*
 * Copyright 2015 Edge Technologies
 */

/**
 * Created by erik on 1/12/2015.
 */

var Splunk = function(appContext) {

  this.baseRule = new BaseWeb(appContext);

  this.onRequest = function(ctx) {

    this.baseRule.onRequest(ctx);
  };

  this.onResponse = function(ctx) {

    this.baseRule.onResponse(ctx);

    // see below instead
    //copyMatchedCookiesToClient(requestContext, "splunkweb_csrf_token_.*");

    // push CSRF cookie to all text/html requests to ensure client doesn't invalidate session
    var contentTypeHeader = ctx.appResponse.getHeaders('content-type');
    if (contentTypeHeader.length > 0 && contentTypeHeader[0].startsWith("text/html")) {
      print("contentType: " + contentTypeHeader[0]);
      var csrfCookie = ctx.cookieCache.getCookieMatch("splunkweb_csrf_token_.*");
      print("splunkweb_csrf_token_.*: " + csrfCookie);
      if (csrfCookie) {
        addCookieToClient(ctx, csrfCookie);
      } else {
        logger.info("Failed to add CSRF cookie to the client.");
        logger.debug("Failed to add CSRF cookie to the client.");
      }
    }
    this.setupResponsePipeline(ctx);
  };

  this.setupResponsePipeline = function(ctx) {

    var feedBase = EdgeWebUrl.makeFeedUrl(ctx.feedName, "");
    var adjFeedBase = feedBase;
    //default locale to US
    var locale = "/en-US";
    if (feedBase.startsWith('/')) {
      //strip the beginning slash
      adjFeedBase = adjFeedBase.slice(1, adjFeedBase.length)
    }

    //Find the URL locale from one of the static JS links that BaseWeb properly maps.
    if (ctx.appRequest.getRequestUri().match("i18n.js")) {
      var url = ctx.appRequest.getRequestUri();
      if (url != null) {
        //match locale substring
        var re = /((\w+)-(\w+))/;
        var localeMatches = url.match(re);
        if (localeMatches.length > 0) {
          locale = '/' + localeMatches[0];
          logger.debug("Found locale... Assigning locale: " + locale);
        }
      }
    }




    // URL mapping
    if (ctx.appResponse.getContentType() &&
      (
        ctx.appResponse.getContentType().search("/javascript") != -1 ||
        ctx.appResponse.getContentType().search("application/json") != -1 ||
        ctx.appResponse.getContentType().search("text/plain") != -1
      ))
    {

      //Need to add checks to ensure that the URL doesn't get double mapped. Seems like it is adding the
      //feedBase twice here.
      // fix config request URI
      var configUrlTextRange = new PlainTextRange("'GET','", "config'");
      configUrlTextRange.addChild(new BasicRegexTransform("(.+)", function (requestContext, matchResult) {
        var newConfigUrl = feedBase + matchResult.group(0);
        return newConfigUrl;
      }));
      ctx.rootSequence.addTransform(new TransformNode(configUrlTextRange, "map config URL"));

      // modify splunkd path in config JS
      var splunkdPathTextRange = new PlainTextRange('"SPLUNKD_PATH": "', '/splunkd/__raw"');
      splunkdPathTextRange.addChild(new BasicRegexTransform("(.+)", function (requestContext, matchResult) {
        var newConfigurationUrl = feedBase + matchResult.group(0);
        //logger.info("Here is the config URL: " + newConfigurationUrl);
        return newConfigurationUrl;
      }));

      ctx.rootSequence.addTransform(new TransformNode(splunkdPathTextRange, "map config URL"));


    }


    //fix MIME type for PNG's
    if (ctx.appRequest.getRequestUri().match(/\.png$/)) {
      setResponseContentType(ctx, 'image/png');

      //TODO: Adjust this to account for other locales
      addTransformsToPipeline(ctx, [
        {
          name: "adjust PNG request URL's",
          find: locale + "/static",
          replace: feedBase + locale + "/static"
        }
      ]);
    }

    else if (ctx.appResponse.getContentType() &&
      (ctx.appResponse.getContentType().search("/javascript") != -1 || ctx.appResponse.getContentType().search("application/json") != -1)) {
      addTransformsToPipeline(ctx, [
        {
          name: "remove logout link",
          find: "logoutLink:logoutLink",
          replace: "logoutLink:null",

        },
        {
          name: "remove account preferences/password changer",
          find: "accountLink:isLite?accountLinkLite:accountLink",
          replace: "accountLink:null"
        },
        //Fix the home link on the app manager page
        {
          name: "fix home link in Manager route",
          range: {
            start: "var homeLink=route.home(",
            stop: ";"
          },
          find: "this.model.application.get('locale')",
          replace: "decodeURIComponent('" + adjFeedBase + "/') + this.model.application.get('locale')"
        },
        {
          name: "fix home link pt. 2",
          find: "homeLink:homeLink",
          replace: "homeLink:decodeURIComponent(homeLink)"
        },
        {
          name: "correct routing issue",
          find: "href:splunk_util.make_url('/app/'+model.entry.get('name'))",
          replace: "href:null"
        }
      ]);
    }
    else if (contentTypeIsHtml(ctx.appRequestContext.getResponseContentType())) {

      //TODO: Adjust this for other locales
      //These can be grouped into one regex rule
      addTransformsToPipeline(ctx, [
        {
          name: "adjust request URL for `swa.js`",
          find: locale + '/static/app/splunk_instrumentation/build/pages/swa.js',
          replace: feedBase + locale + '/static/app/splunk_instrumentation/build/pages/swa.js'
        },
        //TODO: Adjust this for other locales
        {
          name: "fix CSS fetch",
          find: locale + '/static/@8f0ead9ec3db/js/contrib/ace-editor/theme-spl-light.js',
          replace: feedBase + locale + '/static/@8f0ead9ec3db/js/contrib/ace-editor/theme-spl-light.js'
        }

      ]);
      //The config URL does NOT properly pass through to the manager view: do this transformation again here
      //to make sure it passed through.
      var splunkdPathTextRange = new PlainTextRange('"SPLUNKD_PATH": "', '/splunkd/__raw"');
      splunkdPathTextRange.addChild(new BasicRegexTransform("(.+)", function (requestContext, matchResult) {
        var newPathUrl = feedBase + matchResult.group(0);
        return newPathUrl;
      }));

      ctx.rootSequence.addTransform(new TransformNode(splunkdPathTextRange, "map splunkd Path URL"));




      //NEW: works correctly, app management pane functional
      if ((ctx.appRequest.getRequestUri().match('splunkd')) && !(ctx.appRequest.getRequestUri().contains('edgeweb'))) {
        //TODO: Adjust this for other locales
        addTransformsToPipeline(ctx, [
          {
            name: "adjust request links",
            find: locale + '/splunkd',
            replace: feedBase + locale + '/splunkd'
          }
        ]);

        logger.info('Error with request URL: rerouted to ' + ctx.appResponse.getHeader('location'));


      }

      //Configurable header transform
      if (ctx.feed.getAllProperties().getPropertyValueAsBoolean("hideHeader", false)) {

        addTransformsToPipeline(ctx, [
          {
            name: "hide header and footer",
            find: "</head>",
            replace: "<style>header, footer { display: none }</style></head>"
          }
        ]);
      } else {

        if (ctx.appRequest.getRequestUri().match('/app/search/\*')) {

          //TODO: Adjust this for other locales
          //Correct navbar routing
          addTransformsToPipeline(ctx, [
            {
              name: "adjust navbar hyperlinks",
              find: locale + "/app/search",
              replace: feedBase + locale + "/app/search"
            }
          ]);
        }
      }
    }
  };

};

