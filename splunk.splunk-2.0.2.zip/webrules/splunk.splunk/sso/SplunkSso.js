/*
 * Copyright 2015 Edge Technologies
 */

/**
 * Implement SSO for Splunk.
 *
 * Created by erik on 25/09/15.
 */

var SplunkSso = function(appContext) {

    var self = this;

    this.signOn = function(ctx) {

        ctx.appSession.getCookieWorker().removeAllCookies();

        ctx.startSsoRequest("GET", "/", function onInitialResponseWrapper(ctx) { self.onInitialResponse(ctx); });
    };

    this.onInitialResponse = function(ctx) {

        if (ctx.appResponse.getStatusCode() != HttpServletResponse.SC_SEE_OTHER) {
            ctx.appSession.signOnComplete(false);
            return;
        }

        var location = ctx.appResponse.getHeader('location');
        if (!location) {
            ctx.appSession.signOnComplete(false);
            return;
        }

        ctx.startSsoRequest("GET", location, function onGetLoginResponseWrapper(ctx) { self.onGetLoginResponse(ctx); });
    };

    this.onGetLoginResponse = function(ctx) {

        if (ctx.appResponse.getStatusCode() != HttpServletResponse.SC_SEE_OTHER) {
            ctx.appSession.signOnComplete(false);
            return;
        }

        // expecting this to take us to /../login
        var loginPage = ctx.appResponse.getHeader('location');
        if (!loginPage) {
            ctx.appSession.signOnComplete(false);
            return;
        }
        ctx.appSession.setVariable("loginPage", loginPage);

        ctx.startSsoRequest("GET", loginPage, function onCvalResponseWrapper(ctx) { self.onCvalResponse(ctx); });
    };

    this.onCvalResponse = function(ctx) {

        var body = ctx.appResponse.getBody();
        var cval = body.match(/"cval":(.*?),"/);

        if (cval && cval.length > 0) {
            this.makeLoginSubRequest(ctx, cval[1]);
        } else {
            LOGGER.warn("SplunkSso: cval not present in response body");
            ctx.appSession.signOnComplete(false);
        }
    };

    this.makeLoginSubRequest = function(ctx, cval) {

        ctx.startSsoRequest("POST", ctx.appSession.getVariable("loginPage"),
            function onLoginResponseWrapper(ctx) { self.onLoginResponse(ctx); });

        // create the form submission
        ctx.appRequest.setContentType("application/x-www-form-urlencoded");
        ctx.appRequest.addFormParameter('username', ctx.ssoCredentials.get('username'));
        ctx.appRequest.addFormParameter('password', ctx.ssoCredentials.get('password'));
        ctx.appRequest.addFormParameter('cval', cval);
        //appRequest.addFormParameter('return_to', 'en-US'); TODO ?
        //appRequest.addFormParameter('set_has_logged_in', 'true'); TODO ?
    };

    this.onLoginResponse = function(ctx) {

        switch (ctx.appResponse.getStatusCode()) {

            case HttpServletResponse.SC_OK:
                ctx.appSession.signOnComplete(true);
                // TODO remove these as not needed after auth and not being sent correctly (based on path)
                ctx.cookieCache.removeCookies("cval");
                ctx.cookieCache.removeCookies('splunkweb_uid');
                break;

            case HttpServletResponse.SC_UNAUTHORIZED:
            default: // TODO verify this is what we want to do for the default case?  enPortal rules
                     // just do nothing?
                ctx.appSession.signOnComplete(false);
                break;
        }
    };

    this.signOff = function(ctx) {

        ctx.startSsxRequest("GET", ctx.appSession.getVariable("loginPage").replace("login", "logout"));
    };

    this.isExpired = function(ctx) {

        var expired = false;

        var statusCode = ctx.appResponse.getStatusCode();

        if (statusCode == HttpServletResponse.SC_SEE_OTHER) {
            var redirectLocation = ctx.appResponse.getHeader("Location");
            if (redirectLocation.contains("/en-US/account/login?")) {
                expired = true;
                logger.info("Sign on being redirected to " + redirectLocation);
            }
        } else if (statusCode == HttpServletResponse.SC_UNAUTHORIZED) {
            expired = true;
            logger.info("Server responded with 401 Unauthorized. Reaunthenticating...");
            //When we get the auth bug, this block of code is being accessed, meaning expired
            //is certainly set to true.
            //Could this be a cookie issue? Interesting cookie manipulation is Splunk.js...
        }

        return expired;
    };

};
